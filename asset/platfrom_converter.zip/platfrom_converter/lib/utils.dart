class Utils {
  static bool changeDesign = false;
}
